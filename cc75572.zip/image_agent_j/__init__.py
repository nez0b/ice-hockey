from .player import Team

